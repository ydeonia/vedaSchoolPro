-- VedaFlow Branch Backup
-- Branch ID: 28ae6abd-9c2f-41a5-a44f-52eada2f669a
-- Organization ID: 47f82c99-7f22-40ee-95b1-25328f95ea66
-- Created: 2026-03-06T03:59:46.157921
-- Tables: 6
-- Records: 11730

BEGIN;

-- Skipped students: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('students',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped teachers: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('teachers',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped attendance: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('attendance',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped fee_records: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('fee_records',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped fee_structures: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('fee_structures',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped exams: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position]
[parameters: ('exams',)]
(Background on this error at: https://sqlalche.me/e/20/dbapi)
-- Skipped org/branch/users dump: (sqlalchemy.dialects.postgresql.asyncpg.Error) <class 'asyncpg.exceptions.InFailedSQLTransactionError'>: current transaction is aborted, commands ignored until end of transaction block
[SQL: SELECT column_name FROM information_schema.columns WHERE table_name = 'organizations' ORDER BY ordinal_position]
(Background on this error at: https://sqlalche.me/e/20/dbapi)

COMMIT;